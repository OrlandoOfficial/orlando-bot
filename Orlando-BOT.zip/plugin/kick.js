module.exports = {
  name: 'kick',
  command: 'kick',
  async execute(msg, sock) {
    const from = msg.key.remoteJid;
    if (!msg.message?.extendedTextMessage?.contextInfo?.participant) {
      return sock.sendMessage(from, { text: '❗ Balas pesan pengguna yang ingin dikeluarkan dengan #kick' });
    }
    const target = msg.message.extendedTextMessage.contextInfo.participant;
    await sock.groupParticipantsUpdate(from, [target], 'remove');
  }
};
