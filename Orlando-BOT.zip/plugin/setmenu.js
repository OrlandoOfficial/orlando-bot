let menuType = 1;

module.exports = {
  name: 'setmenu',
  command: 'setmenu',
  async execute(msg, sock) {
    const from = msg.key.remoteJid;
    const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
    const type = text.split(' ')[1];

    if (!type || !['1', '2'].includes(type)) {
      return sock.sendMessage(from, {
        text: '❗ Gunakan format: #setmenu 1 atau #setmenu 2'
      });
    }

    menuType = parseInt(type);
    await sock.sendMessage(from, {
      text: `✅ Menu berhasil diubah ke mode ${menuType === 1 ? 'Full Menu' : 'Short Menu'}`
    });
  },
  getMenuType() {
    return menuType;
  }
};
