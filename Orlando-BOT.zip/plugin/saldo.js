const fs = require('fs');

module.exports = {
  name: 'saldo',
  command: 'saldo',
  async execute(msg, sock) {
    const from = msg.key.remoteJid;
    const sender = msg.key.participant || msg.key.remoteJid;
    const nomor = sender.split('@')[0];

    const db = JSON.parse(fs.readFileSync('./lowdb/db.json'));
    db.users = db.users || [];

    const user = db.users.find(u => u.nomor === nomor);
    const saldo = user ? user.saldo : 0;

    await sock.sendMessage(from, { text: `💰 Saldo kamu saat ini: Rp${saldo}` });
  }
};
