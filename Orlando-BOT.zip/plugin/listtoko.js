module.exports = {
  name: 'listtoko',
  command: 'listtoko',
  async execute(msg, sock) {
    const from = msg.key.remoteJid;
    const db = require('../lowdb/db.json');

    if (!db.toko || db.toko.length === 0) {
      return sock.sendMessage(from, { text: '📭 Belum ada toko terdaftar.' });
    }

    const list = db.toko.map((item, i) => `${i + 1}. ${item}`).join('\n');
    await sock.sendMessage(from, { text: `📦 Daftar Toko:
${list}` });
  }
};
