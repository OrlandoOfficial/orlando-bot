const fs = require('fs');

module.exports = {
  name: 'deletelist',
  command: 'deletelist',
  async execute(msg, sock) {
    const from = msg.key.remoteJid;
    const db = require('../lowdb/db.json');
    db.toko = [];
    fs.writeFileSync('./lowdb/db.json', JSON.stringify(db, null, 2));
    await sock.sendMessage(from, { text: '🗑️ Semua data list toko berhasil dihapus.' });
  }
};
