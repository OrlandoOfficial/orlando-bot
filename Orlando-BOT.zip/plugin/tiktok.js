const axios = require('axios');

module.exports = {
  name: 'tiktok',
  command: 'tiktok',
  async execute(msg, sock) {
    const from = msg.key.remoteJid;
    const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
    const args = text.split(' ');
    const url = args[1];
    if (!url) return sock.sendMessage(from, { text: '❗ Masukkan link TikTok' });

    try {
      const res = await axios.get(`https://api.tiklydown.com/api/download?url=${url}`);
      await sock.sendMessage(from, {
        video: { url: res.data.video.no_watermark },
        caption: '✅ Berhasil unduh video TikTok'
      });
    } catch (e) {
      await sock.sendMessage(from, { text: '❌ Gagal unduh video TikTok' });
    }
  }
};
