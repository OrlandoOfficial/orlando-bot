module.exports = {
  name: 'owner',
  command: 'owner',
  async execute(msg, sock) {
    const from = msg.key.remoteJid;
    await sock.sendMessage(from, {
      text: '📞 Hubungi Owner:
https://wa.me/6283106346274
Instagram: @D_Orlando1
Website: https://orlando-digital.my.id'
    });
  }
};
