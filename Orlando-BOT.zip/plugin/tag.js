module.exports = {
  name: 'tag',
  command: 'tag',
  async execute(msg, sock) {
    const from = msg.key.remoteJid;
    const group = await sock.groupMetadata(from);
    const mentions = group.participants.map(p => p.id);
    const mentionText = mentions.map(id => `@${id.split('@')[0]}`).join(' ');
    await sock.sendMessage(from, { text: '🔊 Tag Semua:
' + mentionText, mentions });
  }
};
