// plugin/hello.js
module.exports = {
  name: 'hello',
  command: 'hello',
  async execute(msg, sock) {
    const from = msg.key.remoteJid;
    await sock.sendMessage(from, { text: '👋 Halo! Ini dari plugin dinamis.' });
  }
};
