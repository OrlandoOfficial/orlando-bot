const fs = require('fs');

module.exports = {
  name: 'addtoko',
  command: 'addtoko',
  async execute(msg, sock) {
    const from = msg.key.remoteJid;
    const text = msg.message?.conversation || '';
    const toko = text.replace('#addtoko ', '').trim();
    const db = require('../lowdb/db.json');

    if (!db.toko) db.toko = [];
    db.toko.push(toko);
    fs.writeFileSync('./lowdb/db.json', JSON.stringify(db, null, 2));
    await sock.sendMessage(from, { text: `✅ Toko "${toko}" berhasil ditambahkan.` });
  }
};
