module.exports = {
  name: 'help',
  command: 'help',
  async execute(msg, sock) {
    const from = msg.key.remoteJid;
    const bantuan = `
🆘 Bantuan Perintah:

📁 Manajemen Toko:
#addtoko NamaToko
#deltoko NamaToko
#listtoko

📢 Admin Tools:
#tag
#kick (balas pesan)
#broadcast pesan

🔐 Otentikasi:
#auth
#addpremium nomor

📥 Downloader:
#tiktok url
#igdl url
#sticker (balas gambar)

📌 Lainnya:
#menu
#owner
#ping
#help
    `.trim();
    await sock.sendMessage(from, { text: bantuan });
  }
};
