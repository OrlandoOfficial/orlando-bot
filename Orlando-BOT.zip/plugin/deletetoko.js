const fs = require('fs');

module.exports = {
  name: 'deletetoko',
  command: 'deletetoko',
  async execute(msg, sock) {
    const from = msg.key.remoteJid;
    const text = msg.message?.conversation || '';
    const index = parseInt(text.split(' ')[1]);
    const db = require('../lowdb/db.json');

    if (isNaN(index) || index < 1 || index > db.toko.length) {
      return sock.sendMessage(from, { text: '⚠️ Index tidak valid. Gunakan: #deletetoko 1' });
    }

    const removed = db.toko.splice(index - 1, 1);
    fs.writeFileSync('./lowdb/db.json', JSON.stringify(db, null, 2));
    await sock.sendMessage(from, { text: `🗑️ Toko "${removed[0]}" berhasil dihapus.` });
  }
};
