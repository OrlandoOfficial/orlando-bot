module.exports = {
  name: 'broadcast',
  command: 'broadcast',
  async execute(msg, sock) {
    const from = msg.key.remoteJid;
    const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
    const pesan = text.replace('#broadcast ', '').trim();
    if (!pesan) return sock.sendMessage(from, { text: '❗ Masukkan isi broadcast' });

    const groups = await sock.groupFetchAllParticipating();
    for (let jid in groups) {
      await sock.sendMessage(jid, { text: `📢 Broadcast:
${pesan}` });
    }
    await sock.sendMessage(from, { text: '✅ Broadcast terkirim ke semua grup.' });
  }
};
