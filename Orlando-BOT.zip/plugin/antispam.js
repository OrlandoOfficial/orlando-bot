const antiSpamCache = new Map();

module.exports = {
  name: 'antispam',
  command: 'antispam',
  async execute(msg, sock) {
    const from = msg.key.remoteJid;
    const sender = msg.key.participant || msg.key.remoteJid;

    const now = Date.now();
    const last = antiSpamCache.get(sender) || 0;
    if (now - last < 3000) {
      await sock.sendMessage(from, { text: '⚠️ Jangan spam!' });
    } else {
      antiSpamCache.set(sender, now);
      await sock.sendMessage(from, { text: '✅ Kamu tidak spam.' });
    }
  }
};
