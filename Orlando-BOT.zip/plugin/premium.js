module.exports = {
  name: 'addpremium',
  command: 'addpremium',
  async execute(msg, sock) {
    const sender = msg.key.participant || msg.key.remoteJid;
    const nomor = msg.message?.conversation?.split(' ')[1] || '';
    const from = msg.key.remoteJid;
    const db = require('../datastore.json');
    const fs = require('fs');

    if (!db.owner.includes(sender.split('@')[0])) {
      return sock.sendMessage(from, { text: '❌ Hanya owner yang bisa menambah premium' });
    }

    if (nomor && !db.premium.includes(nomor)) {
      db.premium.push(nomor);
      fs.writeFileSync('./datastore.json', JSON.stringify(db, null, 2));
      await sock.sendMessage(from, { text: `✅ ${nomor} ditambahkan sebagai premium.` });
    } else {
      await sock.sendMessage(from, { text: '⚠️ Nomor tidak valid atau sudah premium.' });
    }
  }
};
