const fs = require('fs');

module.exports = {
  name: 'beli',
  command: 'beli',
  async execute(msg, sock) {
    const from = msg.key.remoteJid;
    const sender = msg.key.participant || msg.key.remoteJid;
    const nomor = sender.split('@')[0];
    const text = msg.message?.conversation || '';
    const args = text.split(' ');
    const item = args[1];
    const harga = parseInt(args[2]);

    if (!item || isNaN(harga)) {
      return sock.sendMessage(from, {
        text: '❗ Format salah. Contoh: #beli followers 5000'
      });
    }

    const db = JSON.parse(fs.readFileSync('./lowdb/db.json'));
    db.users = db.users || [];

    const user = db.users.find(u => u.nomor === nomor);
    if (!user) return sock.sendMessage(from, { text: '⚠️ Kamu belum terdaftar. Silakan deposit terlebih dahulu.' });

    if (user.saldo < harga) {
      return sock.sendMessage(from, { text: `❌ Saldo kamu tidak cukup. Sisa saldo: Rp${user.saldo}` });
    }

    user.saldo -= harga;

    db.transaksi = db.transaksi || [];
    db.transaksi.push({ nomor, item, harga, waktu: new Date().toISOString() });

    fs.writeFileSync('./lowdb/db.json', JSON.stringify(db, null, 2));

    await sock.sendMessage(from, {
      text: `🛒 Pembelian *${item}* seharga Rp${harga} berhasil!
Sisa saldo: Rp${user.saldo}`
    });

    await sock.sendMessage('6283106346274@s.whatsapp.net', {
      text: `🔔 Pembelian Baru:
Nomor: ${nomor}
Produk: ${item}
Harga: Rp${harga}`
    });
  }
};
