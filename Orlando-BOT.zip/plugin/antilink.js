module.exports = {
  name: 'antilink',
  command: 'antilink',
  async execute(msg, sock) {
    const from = msg.key.remoteJid;
    const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
    const setting = text.split(' ')[1];
    if (!setting || !['on', 'off'].includes(setting)) {
      return sock.sendMessage(from, { text: 'Gunakan: #antilink on / off' });
    }

    const chatData = require('../lowdb/db.json');
    chatData.settings[from] = { antilink: setting === 'on' };
    require('fs').writeFileSync('./lowdb/db.json', JSON.stringify(chatData, null, 2));

    await sock.sendMessage(from, { text: `✅ Antilink telah ${setting === 'on' ? 'diaktifkan' : 'dinonaktifkan'}` });
  }
};
