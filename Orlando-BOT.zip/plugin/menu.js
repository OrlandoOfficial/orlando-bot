const { getMenuType } = require('./setmenu');

module.exports = {
  name: 'menu',
  command: 'menu',
  async execute(msg, sock) {
    const from = msg.key.remoteJid;

    const garis = '───────────────';
    const menuType = getMenuType();

    if (menuType === 1) {
      const menu = `╭${garis}
│ ⫹⫺ 𝗢𝗥𝗟𝗔𝗡𝗗𝗢 𝗕𝗢𝗧 - MENU
├${garis}
│ #menu
│ #ping
│ #owner
│ #tiktok [url]
│ #igdl [url]
│ #sticker
│ #pushkontak
│ #broadcast
│ #tag
│ #kick
│ #deposit
│ #saldo
│ #beli
│ #help
╰${garis}`;
      return sock.sendMessage(from, { text: menu });
    } else {
      const menu2 = `🧩 *Short Menu*
#tiktok [url]
#igdl [url]
#sticker
#owner
#help
#beli
#saldo
#deposit
#menu ➜ tampil ulang
#setmenu 1 / 2 ➜ ganti tampilan`;
      return sock.sendMessage(from, { text: menu2 });
    }
  }
};
