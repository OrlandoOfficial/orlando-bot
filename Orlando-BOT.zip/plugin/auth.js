module.exports = {
  name: 'auth',
  command: 'auth',
  async execute(msg, sock) {
    const from = msg.key.remoteJid;
    const user = msg.key.participant || msg.key.remoteJid;
    const nomor = user.split('@')[0];
    const db = require('../datastore.json');

    if (db.owner.includes(nomor)) {
      await sock.sendMessage(from, { text: '🛡️ Anda adalah OWNER' });
    } else if (db.premium.includes(nomor)) {
      await sock.sendMessage(from, { text: '⭐ Anda adalah pengguna PREMIUM' });
    } else {
      await sock.sendMessage(from, { text: '❌ Anda pengguna biasa' });
    }
  }
};
