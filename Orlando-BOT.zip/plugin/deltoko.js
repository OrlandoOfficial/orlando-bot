const fs = require('fs');

module.exports = {
  name: 'deltoko',
  command: 'deltoko',
  async execute(msg, sock) {
    const from = msg.key.remoteJid;
    const text = msg.message?.conversation || '';
    const toko = text.replace('#deltoko ', '').trim();
    const db = require('../lowdb/db.json');

    if (!db.toko) db.toko = [];
    db.toko = db.toko.filter(item => item !== toko);
    fs.writeFileSync('./lowdb/db.json', JSON.stringify(db, null, 2));
    await sock.sendMessage(from, { text: `🗑️ Toko "${toko}" berhasil dihapus.` });
  }
};
