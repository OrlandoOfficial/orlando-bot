const { sticker } = require('wa-sticker-formatter');

module.exports = {
  name: 'sticker',
  command: 'sticker',
  async execute(msg, sock) {
    const from = msg.key.remoteJid;
    if (!msg.message?.imageMessage) {
      return sock.sendMessage(from, { text: '❗ Balas gambar dengan #sticker' });
    }
    const stream = await downloadMediaMessage(msg, 'buffer');
    const stickerBuffer = await sticker(stream, { pack: 'OrlandoBot', author: 'Orlando' });
    await sock.sendMessage(from, { sticker: stickerBuffer });
  }
};
