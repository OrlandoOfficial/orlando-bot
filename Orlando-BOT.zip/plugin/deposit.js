const fs = require('fs');
const path = './lowdb/db.json';

module.exports = {
  name: 'deposit',
  command: 'deposit',
  async execute(msg, sock) {
    const from = msg.key.remoteJid;
    const sender = msg.key.participant || msg.key.remoteJid;
    const nomor = sender.split('@')[0];
    const text = msg.message?.conversation || '';
    const jumlah = parseInt(text.split(' ')[1]);

    const db = JSON.parse(fs.readFileSync(path));
    db.users = db.users || [];

    let user = db.users.find(u => u.nomor === nomor);
    if (!user) {
      user = { nomor, saldo: 0 };
      db.users.push(user);
    }

    if (!jumlah || isNaN(jumlah) || jumlah < 10000) {
      return sock.sendMessage(from, {
        text: '❗ Minimal deposit Rp10.000
Format: #deposit 10000'
      });
    }

    user.saldo += jumlah;
    fs.writeFileSync(path, JSON.stringify(db, null, 2));
    await sock.sendMessage(from, { text: `✅ Deposit Rp${jumlah} berhasil ditambahkan ke saldo.` });
  }
};
