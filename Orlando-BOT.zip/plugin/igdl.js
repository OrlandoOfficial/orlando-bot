const axios = require('axios');

module.exports = {
  name: 'igdl',
  command: 'igdl',
  async execute(msg, sock) {
    const from = msg.key.remoteJid;
    const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
    const args = text.split(' ');
    const url = args[1];
    if (!url) return sock.sendMessage(from, { text: '❗ Masukkan link Instagram' });

    try {
      const res = await axios.get(`https://api.instagramdownloader.io/api/download?url=${url}`);
      const media = res.data.media[0];
      await sock.sendMessage(from, {
        video: { url: media },
        caption: '✅ Berhasil unduh video IG'
      });
    } catch (e) {
      await sock.sendMessage(from, { text: '❌ Gagal unduh video Instagram' });
    }
  }
};
