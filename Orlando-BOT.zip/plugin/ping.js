module.exports = {
  name: 'ping',
  command: 'ping',
  async execute(msg, sock) {
    const from = msg.key.remoteJid;
    await sock.sendMessage(from, { text: '🏓 Pong aktif!' });
  }
};
