<h1 align="center">⫹⫺ 𝗢𝗥𝗟𝗔𝗡𝗗𝗢 𝗕𝗢𝗧</h1>
<p align="center">
  Bot WhatsApp Multifungsi • Premium • Toko Produk Sosmed • Deposit & Transaksi Otomatis
</p>

<p align="center">
  <a href="https://wa.me/6283106346274"><img src="https://img.shields.io/badge/Owner-OrlandoOfficial-green?style=flat-square" /></a>
  <a href="https://orlando-digital.my.id"><img src="https://img.shields.io/badge/Website-Orlando%20Digital-blue?style=flat-square" /></a>
</p>

---

## ✨ Fitur Utama

- 🔰 Sistem Plugin Dinamis (Tambah/muat plugin dengan mudah)
- 👑 Manajemen Owner & Premium
- 🛍️ Fitur Toko Produk Sosmed (add/del/list toko)
- 💰 Deposit manual via QRIS + saldo otomatis
- 🛒 Pembelian produk dari saldo
- 👥 Broadcast & Push Kontak ke semua grup
- 🔒 Anti Spam, Anti Link Grup
- 🕌 Jadwal Sholat Otomatis (kirim ke semua grup)
- 📦 Downloader TikTok, Instagram, Sticker, dll
- ⚙️ Set Prefix, Menu 1 & 2 (pilih tampilan menu)
- 📡 Support Termux & VPS

---

## 🧠 Perintah Menu

| Kategori         | Command Utama                                  |
|------------------|------------------------------------------------|
| 🔧 Sistem        | `#menu`, `#setmenu 1/2`, `#setprefix #`         |
| 👑 Owner         | `#addowner`, `#addpremium`, `#setnamabot`       |
| 📦 Produk        | `#addtoko`, `#deltoko`, `#deletelist`, `#listtoko` |
| 💰 Saldo         | `#deposit`, `#saldo`, `#beli followers 10000`   |
| 📥 Downloader    | `#tiktok`, `#igdl`, `#sticker`                  |
| 📢 Admin Group   | `#tag`, `#kick`, `#broadcast`, `#pushkontak`    |
| 🔐 Cek Status    | `#auth`, `#ping`, `#owner`, `#help`             |

---

## 🧾 Struktur Folder

orlando-bot/
├── plugin/ # Semua perintah/plugin dinamis
├── lib/ # Loader plugin
├── lowdb/ # Penyimpanan database JSON
├── sessions/ # Data login WA
├── asseth/Image/ # Logo & QRIS
├── Config.js # Konfigurasi global bot
├── Main.js # Entry point utama bot
├── Package.json # Dependensi & script
├── README.md # Dokumentasi (file ini)


---

## ⚙️ Instalasi & Jalankan

```bash
# Clone repo
git clone https://github.com/OrlandoOfficial/orlando-bot
cd orlando-bot

# Install dependensi
npm install

# Jalankan bot
node Main.js
