// orlando.js — entry atau export modul global
const { formatDate, isOwner } = require('./lib/helpers');
const { db, initDB } = require('./lowdb/database');

module.exports = {
  formatDate,
  isOwner,
  db,
  initDB
};
