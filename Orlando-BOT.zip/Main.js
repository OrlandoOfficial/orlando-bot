const { loadPlugins, handlePlugins } = require('./lib/plugins');
// Final Update OrlandoBot - Menu Tipe 1 dan 2, Loading, Branding Fixes

const readline = require('readline');
const { makeWASocket, useSingleFileAuthState, fetchLatestBaileysVersion, generateWAMessageContent, downloadMediaMessage } = require('@adiwajshing/baileys');
const { state, saveState } = useSingleFileAuthState('./sessions/OrlandoOfficial.json');
const fs = require('fs');
const pino = require('pino');
const axios = require('axios');
const moment = require('moment-timezone');

let prefix = '#';
let menuType = 1;
let sock;

const config = {
  owner: ['6283106346274'],
  botName: '⫹⫺ 𝗢𝗿𝗹𝗮𝗻𝗱𝗼 𝗕𝗢𝗧',
  ownerName: '𝙊𝙧𝙡𝙖𝙣𝙙𝙤 𝙊𝙛𝙛𝙞𝙘𝙞𝙖𝙡',
  botNumber: '62895433466090'
};

let dataStore = { owner: config.owner, premium: [] };
try { dataStore = JSON.parse(fs.readFileSync('./datastore.json')); } catch (e) { fs.writeFileSync('./datastore.json', JSON.stringify(dataStore, null, 2)); }
function saveStore() { fs.writeFileSync('./datastore.json', JSON.stringify(dataStore, null, 2)); }

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

rl.question('Masukkan Nomor WhatsApp (+62xxx): ', async function(inputNumber) {
  if (!inputNumber.startsWith('+62')) {
    console.log('❌ Nomor harus diawali +62');
    process.exit(0);
  }

  const { version } = await fetchLatestBaileysVersion();
  sock = makeWASocket({
    version,
    auth: state,
    printQRInTerminal: false,
    logger: pino({ level: 'silent' }),
    getMessage: async () => ({ conversation: 'ok' })
  });

  sock.ev.on('creds.update', saveState);
  loadPlugins();

  sock.ev.on('connection.update', async ({ connection, qr, pairingCode }) => {
    if (connection === 'open') {
      console.log('\x1b[32mBOT BERHASIL TERPASANG\x1b[0m');
      autoSholatReminder();
    } else if (qr) {
      console.log('📎 Silakan scan QR ini dari WhatsApp:');
      require('qrcode-terminal').generate(qr, { small: true });
    } else if (pairingCode) {
      console.log(`📲 Kode Tautan WA untuk ${inputNumber}: ${pairingCode}`);
    } else if (connection === 'close') {
      console.log('\x1b[31mBOT GAGAL TERHUBUNG\x1b[0m');
    }
  });

  sock.ev.on('messages.upsert', async ({ messages }) => {
    const msg = messages[0];
    if (!msg.message || msg.key.fromMe) return;
    await handlePlugins(msg, sock);

    const from = msg.key.remoteJid;
    const text = msg.message.conversation || msg.message.extendedTextMessage?.text || '';
    const sender = msg.key.participant || msg.key.remoteJid;
    const nomor = sender.split('@')[0];
    const isOwner = dataStore.owner.includes(nomor);
    const isPremium = dataStore.premium.includes(nomor);

    if (text === prefix + 'menu') {
      await sock.sendMessage(from, { text: 'Loading...(10%)' });
      await sock.sendMessage(from, { text: 'Loading...(65%)' });
      await sock.sendMessage(from, { text: 'Loading...(99%)' });
      await sock.sendMessage(from, { text: 'Loading...(Selesai)' });

      const garis = '───────────────';
      if (menuType === 1) {
        const menu = `╭${garis}\n│ ${config.botName}\n├${garis}\n│ Prefix : ${prefix}\n│ Owner  : ${config.ownerName}\n│ Nomor  : wa.me/${config.botNumber}\n├${garis}\n│ ${prefix}menu\n│ ${prefix}tiktok\n│ ${prefix}igdl\n│ ${prefix}sticker\n│ ${prefix}pushkontak\n│ ${prefix}broadcast\n│ ${prefix}tag\n│ ${prefix}kick\n│ ${prefix}owner\n╰${garis}`;
        return sock.sendMessage(from, { text: menu });
      } else {
        const menu2 = `🧩 *Short Menu*\n${prefix}tiktok\n${prefix}igdl\n${prefix}sticker\n${prefix}owner ➜ untuk lihat fitur admin\n${prefix}menu1 / ${prefix}menu2 ➜ ganti tampilan`; 
        return sock.sendMessage(from, { text: menu2 });
      }
    }

    if (text === prefix + 'menu1') {
      menuType = 1;
      return sock.sendMessage(from, { text: '✅ Berhasil mengubah ke Menu Tipe 1 (Full Menu)' });
    }

    if (text === prefix + 'menu2') {
      menuType = 2;
      return sock.sendMessage(from, { text: '✅ Berhasil mengubah ke Menu Tipe 2 (Short Menu)' });
    }

    if (text === prefix + 'owner') {
      return sock.sendMessage(from, { text: `*Owner Menu*\n${prefix}addpremium nomor\n${prefix}addowner nomor\n${prefix}setprefix simbol\n${prefix}setmenu 1/2\n${prefix}addplugin kode\n${prefix}setnamabot Nama\n${prefix}setfotobot (reply image)` });
    }
  });
});

function autoSholatReminder() {
  setInterval(async () => {
    let now = moment().tz('Asia/Jakarta');
    let hour = now.hour();
    let minute = now.minute();
    let send = false;
    let waktu = '';

    if (hour === 4 && minute === 30) waktu = 'Subuh', send = true;
    else if (hour === 12 && minute === 0) waktu = 'Dzuhur', send = true;
    else if (hour === 15 && minute === 0) waktu = 'Ashar', send = true;
    else if (hour === 18 && minute === 0) waktu = 'Maghrib', send = true;
    else if (hour === 19 && minute === 30) waktu = 'Isya', send = true;

    if (send) {
      let groups = await sock.groupFetchAllParticipating();
      let message = `🕌 *Waktunya Sholat ${waktu}*\n📅 ${now.format('dddd, DD MMMM YYYY')}\n⏰ Jam: ${now.format('HH:mm')} WIB`;
      for (let jid in groups) {
        sock.sendMessage(jid, { text: message });
      }
    }
  }, 60000);
}
