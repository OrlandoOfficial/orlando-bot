// Config.js — Konfigurasi utama Orlando BOT

module.exports = {
  owner: ['6283106346274'],
  botName: '⫹⫺ 𝗢𝗿𝗹𝗮𝗻𝗱𝗼 𝗕𝗢𝗧',
  ownerName: '𝙊𝙧𝙡𝙖𝙣𝙙𝙤 𝙊𝙛𝙛𝙞𝙘𝙞𝙖𝙡',
  botNumber: '62895433466090',
  instagram: 'https://instagram.com/D_Orlando1',
  whatsapp: 'https://wa.me/6283106346274',
  website: 'https://orlando-digital.my.id',
  prefix: '#',
  premiumPrice: 15000,
  premiumDuration: 7, // in days
  adminFee: 500,
  minDeposit: 10000,
  menuType: 1, // default: full menu
  sessionFile: './sessions/OrlandoOfficial.json',
  qrisImage: './asseth/Image/qris.jpg',
  logoImage: './asseth/Image/logo.jpg'
};
