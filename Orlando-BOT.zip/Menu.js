const { botName, ownerName, whatsapp } = require('./Config');

exports.menuFull = () => {
  return `
╭───────────────
│ ${botName}
├───────────────
│ Prefix : #
│ Owner  : ${ownerName}
│ Kontak : ${whatsapp}
├───────────────
│ #menu
│ #tiktok
│ #igdl
│ #sticker
│ #pushkontak
│ #broadcast
│ #tag
│ #kick
│ #owner
╰───────────────
`.trim();
};

exports.menuShort = () => {
  return `
🧩 *Short Menu*
#tiktok
#igdl
#sticker
#owner ➜ fitur admin
#menu1 / #menu2 ➜ ganti tampilan
`.trim();
};
