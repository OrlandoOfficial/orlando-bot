// lowdb/database.js — inisialisasi penyimpanan JSON lokal
const { Low, JSONFile } = require('lowdb');
const db = new Low(new JSONFile('./lowdb/db.json'));

async function initDB() {
  await db.read();
  db.data ||= { users: [], settings: {} };
  await db.write();
}

module.exports = { db, initDB };
