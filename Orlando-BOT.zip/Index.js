// Index.js — Entry point of Orlando BOT
console.log("🚀 Starting ⫹⫺ 𝗢𝗿𝗹𝗮𝗻𝗱𝗼 𝗕𝗢𝗧...");
require('./Main');
