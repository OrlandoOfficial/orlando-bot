#!/bin/bash
echo "📦 Menjalankan ⫹⫺ 𝗢𝗿𝗹𝗮𝗻𝗱𝗼 𝗕𝗢𝗧..."
node Main.js
